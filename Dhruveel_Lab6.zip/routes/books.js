const express = require("express");
const router = express.Router();
const data = require("../data/");
const bookData = data.books;
// const reviewData = data.reviews;

/*
routes/books.js

1. GET /books
2. POST /books
3. GET /books/{id}
4. PUT /books/{id}
5. PATCH /books/{id}
6. DELETE /books/{id}
*/

// 1. GET /books
router.get("/", async (req, res) => {
  try {
    const allBooks = await bookData.getAllBooks();
    res.json(allBooks);
  } catch (err) {
    res.status(404).json({ message: "Books data is empty." });
  }
});

// 2. POST /books
router.post("/", async (req, res) => {
  let bookInfo = req.body;

  if (!bookInfo) {
    res.status(400).json({ error: "You must provide a proper data." });
    return;
  }
  if (!bookInfo.title) {
    res.status(400).json({ error: "You must provide a title." });
    return;
  }
  if (!bookInfo.authorFirstName) {
    res.status(400).json({
      error: "You must provide a authorFirstName.",
    });
    return;
  }
  if (!bookInfo.authorLastName) {
    res.status(400).json({ error: "You must provide a authorLastName." });
    return;
  }
  if (!bookInfo.genre) {
    res.status(400).json({ error: "You must provide a genre." });
    return;
  }
  if (!bookInfo.datePublished) {
    res.status(400).json({ error: "You must provide a date of publishion." });
    return;
  }

  if (!bookInfo.summary) {
    res.status(400).json({
      error: "You must provide a summary.",
    });
    return;
  }
  if (
    Array.isArray(bookInfo.genre) !== true ||
    bookInfo.genre.length < 1 ||
    bookInfo.genre.forEach((element) => {
      if (typeof element !== "string" || element.trim().length === 0)
        throw `The provided genre: ${element} is not in proper type or is empty.`;
    })
  ) {
    res.status(500).json({
      message: "Genre need to be a string.",
    });
  }

  try {
    const newBook = await bookData.addBook(
      bookInfo.title,
      bookInfo.authorFirstName,
      bookInfo.authorLastName,
      bookInfo.genre,
      bookInfo.datePublished,
      bookInfo.summary
    );
    res.json(newBook);
  } catch (e) {
    res.status(500); //.json({ message: `Inputs are not provided properly.` });
  }
});

// 3. GET /books/{id}
router.get("/:id", async (req, res) => {
  try {
    let book = await bookData.getBookById(req.params.id);
    res.json(book);
  } catch (err) {
    res
      .status(404)
      .json({ message: `no book found with an id: ${req.params.id}` });
  }
});
//   return;

// 4. PUT /books/{id}
router.put("/:id", async (req, res) => {
  const updateData = req.body;
  if (
    !updateData ||
    !updateData.title ||
    !updateData.authorFirstName ||
    !updateData.authorLastName ||
    !updateData.genre ||
    !updateData.datePublished ||
    !updateData.summary
  ) {
    res.status(400).json({ message: "You must supply all the parameters." });
    return;
  }
  try {
    await bookData.getBookById(req.params.id);
    return;
  } catch (error) {
    res.status({ message: "Post not found." });
  }

  try {
    const updatedBook = await bookData.updateBook(req.params.id, updateData);
    res.json(updatedBook);
  } catch (error) {
    res.status(500).json({ message: "Not able to update the book data." });
  }
});

// 5. PATCH /books/{id}
router.patch("/:id", async (req, res) => {
  const bookInfo = req.body;
  let updatedObj = {};
  // updatedObj.author = {};

  try {
    const oldBookData = await bookData.getBookById(req.params.id);

    // const { author: old } = oldBookData;

    if (bookInfo.title && bookInfo.title !== oldBookData.title)
      updatedObj.title = bookInfo.title;

    if (
      (bookInfo.authorFirstName &&
        bookInfo.authorFirstName !== oldBookData.authorFirstName) ||
      !oldBookData.authorFirstName
    )
      updatedObj.authorFirstName = bookInfo.authorFirstName;

    if (
      (bookInfo.authorLastName &&
        bookInfo.authorLastName !== oldBookData.authorLastName) ||
      !oldBookData.authorLastName
    )
      updatedObj.authorLastName = bookInfo.authorLastName;

    // if (author.authorFirstName || author.authorLastName)
    //   updatedObj.author = author;

    if (bookInfo.genre && bookInfo.genre !== oldBookData.genre)
      updatedObj.genre = bookInfo.genre;
    if (
      bookInfo.datePublished &&
      bookInfo.datePublished !== oldBookData.datePublished
    )
      updatedObj.datePublished = bookInfo.datePublished;
    if (bookInfo.summary && bookInfo.summary !== oldBookData.summary)
      updatedObj.summary = bookInfo.summary;
  } catch (error) {
    res.status(500).json({ message: "Not able to patch the book." });
    return;
  }

  if (Object.keys(updatedObj).length !== 0) {
    try {
      const updatingBook = await bookData.updateBook(req.params.id, updatedObj);
      res.json(updatingBook);
    } catch (error) {
      res.status(500).json({ message: "Error while updating from patch." });
    }
  } else {
    res.status(400).json({
      message:
        "Nofield have been changed from their initial values, so no update.",
    });
  }
});

// 6. DELETE /books/{id}
router.delete("/:id", async (req, res) => {
  if (!req.params.id)
    res.status(500).json({ message: "Id need to be provided." });
  try {
    const bookD = await bookData.deleteBookById(req.params.id);
    res.json(bookD);
  } catch (error) {
    console.log(error);
  }
});
module.exports = router;
