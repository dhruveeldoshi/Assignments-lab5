const reviewsRoutes = require("./reviews");
const booksRoutes = require("./books");

const constructorMethod = (app) => {
  app.use("/reviews", reviewsRoutes);
  app.use("/books", booksRoutes);

  app.use("*", (req, res) => {
    res.sendStatus(404);
  });
};

module.exports = constructorMethod;
