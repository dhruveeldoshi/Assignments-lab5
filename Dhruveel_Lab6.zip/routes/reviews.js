const express = require("express");
const router = express.Router();
const data = require("../data/");
const reviewData = data.reviews;

/*
routes/reviews.js

1. GET /reviews/{bookId}
2. POST /reviews/{bookId}
3. GET /reviews/review/{reviewId}
4. Delete /reviews/{reviewId)
*/

// 1. GET /reviews/{bookId}
router.get("/:id", async (req, res) => {
  try {
    let review = await reviewData.getReviewByBookId(req.params.id);

    res.json(review);
  } catch (error) {
    res.status(404).json({ message: "No reviews found for that book." });
  }
});

// 2. POST /reviews/{bookId}
router.post("/:id", async (req, res) => {
  reviewBody = req.body;
  if (!reviewBody) {
    res.status(500).json({ message: "Please pass all review parameters." });
  }
  if (!reviewBody.title) {
    res.status(500).json({ message: "Pass review title." });
    return;
  }
  if (!reviewBody.reviewer) {
    res.status(500).json({ message: "Pass reviewer." });
    return;
  }
  if (!reviewBody.rating) {
    res.status(500).json({ message: "Pass review rating." });
    return;
  }
  if (!reviewBody.dateOfReview) {
    res.status(500).json({ message: "Pass review Date." });
    return;
  }
  if (!reviewBody.review) {
    res.status(500).json({ message: "Pass review." });
    return;
  }

  try {
    const addReview = {
      title: reviewBody.title,
      reviewer: reviewBody.reviewer,
      rating: reviewBody.rating,
      dateOfReview: reviewBody.dateOfReview,
      review: reviewBody.review,
    };
    const reviewAdded = await reviewData.addReviews(req.params.id, addReview);
    res.json(reviewAdded);
  } catch (error) {
    res.status(500).json({ message: "Error: Not able to Add reviews" });
  }
});

// 3. GET /reviews/review/{reviewId}
router.get("review/:id", async (req, res) => {
  try {
    let reviewByRid = await reviewData.getReviewByReviewId(req.params.id);
    res.json(reviewByRid);
  } catch (error) {
    res.status(404).json({ message: "No Book Found with that ID" });
  }
});

// 4. Delete /reviews/{reviewId}
router.delete("/:id", async (req, res) => {});

module.exports = router;
